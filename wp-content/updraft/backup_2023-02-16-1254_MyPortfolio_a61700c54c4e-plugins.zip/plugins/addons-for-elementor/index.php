<?php
/* Silence is Golden */